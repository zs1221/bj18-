# __init__.py

__version__ = '2.2.0'
VERSION = tuple(map(int, __version__.split('.')))

